﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarGUI.Model
{
    public class Authentication
    {
        public static bool isAdmin = false;
    }
}
